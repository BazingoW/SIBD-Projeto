<html>
	<body>
		<h1><strong><font color= '#66CC00'>Welcome to the Healthcare Centre</font></strong></h1>
		<hr/>
		<form action="getPatient.php" method="post">
 			<p>Search for/Insert a patient: <input type="submit" value="Search"/></p>
		</form>
		<form action="newStudy.php" method="post">
 			<p>Create a study: <input type="submit" value="New Study"/></p>
		</form>
		<form action="getRegion.php" method="post">
 			<p>Add a region to an element: <input type="submit" value="New Region"/></p>
		</form>
	</body>
</html>